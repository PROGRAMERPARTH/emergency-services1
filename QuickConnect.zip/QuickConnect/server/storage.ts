import { type User, type InsertUser, type EmergencyContact, type InsertEmergencyContact, type MedicalInfo, type InsertMedicalInfo } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: Omit<InsertUser, 'confirmPassword'>): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Emergency contacts
  getEmergencyContacts(userId: string): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact & { userId: string }): Promise<EmergencyContact>;
  updateEmergencyContact(id: string, updates: Partial<EmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: string): Promise<boolean>;

  // Medical information
  getMedicalInfo(userId: string): Promise<MedicalInfo | undefined>;
  createOrUpdateMedicalInfo(info: InsertMedicalInfo & { userId: string }): Promise<MedicalInfo>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private emergencyContacts: Map<string, EmergencyContact>;
  private medicalInfo: Map<string, MedicalInfo>;

  constructor() {
    this.users = new Map();
    this.emergencyContacts = new Map();
    this.medicalInfo = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: Omit<InsertUser, 'confirmPassword'>): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      username: insertUser.username,
      email: insertUser.email,
      fullName: insertUser.fullName,
      password: insertUser.password,
      id,
      avatar: null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    console.log(`User created: ${user.username}, total users: ${this.users.size}`);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getEmergencyContacts(userId: string): Promise<EmergencyContact[]> {
    return Array.from(this.emergencyContacts.values()).filter(
      (contact) => contact.userId === userId,
    );
  }

  async createEmergencyContact(contact: InsertEmergencyContact & { userId: string }): Promise<EmergencyContact> {
    const id = randomUUID();
    const emergencyContact: EmergencyContact = {
      ...contact,
      id,
      email: contact.email || null,
      isPrimary: contact.isPrimary || "false",
      createdAt: new Date()
    };
    this.emergencyContacts.set(id, emergencyContact);
    return emergencyContact;
  }

  async updateEmergencyContact(id: string, updates: Partial<EmergencyContact>): Promise<EmergencyContact | undefined> {
    const contact = this.emergencyContacts.get(id);
    if (!contact) return undefined;
    
    const updatedContact = { ...contact, ...updates };
    this.emergencyContacts.set(id, updatedContact);
    return updatedContact;
  }

  async deleteEmergencyContact(id: string): Promise<boolean> {
    return this.emergencyContacts.delete(id);
  }

  async getMedicalInfo(userId: string): Promise<MedicalInfo | undefined> {
    return Array.from(this.medicalInfo.values()).find(
      (info) => info.userId === userId,
    );
  }

  async createOrUpdateMedicalInfo(info: InsertMedicalInfo & { userId: string }): Promise<MedicalInfo> {
    const existing = await this.getMedicalInfo(info.userId);
    
    if (existing) {
      const updated: MedicalInfo = {
        ...existing,
        ...info,
        bloodType: info.bloodType || null,
        allergies: Array.isArray(info.allergies) ? info.allergies : null,
        medications: Array.isArray(info.medications) ? info.medications : null,
        medicalConditions: Array.isArray(info.medicalConditions) ? info.medicalConditions : null,
        emergencyNotes: info.emergencyNotes || null,
        doctorName: info.doctorName || null,
        doctorPhone: info.doctorPhone || null,
        updatedAt: new Date()
      };
      this.medicalInfo.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const medicalRecord: MedicalInfo = {
        ...info,
        id,
        bloodType: info.bloodType || null,
        allergies: Array.isArray(info.allergies) ? info.allergies : null,
        medications: Array.isArray(info.medications) ? info.medications : null,
        medicalConditions: Array.isArray(info.medicalConditions) ? info.medicalConditions : null,
        emergencyNotes: info.emergencyNotes || null,
        doctorName: info.doctorName || null,
        doctorPhone: info.doctorPhone || null,
        updatedAt: new Date()
      };
      this.medicalInfo.set(id, medicalRecord);
      return medicalRecord;
    }
  }
}

export const storage = new MemStorage();
