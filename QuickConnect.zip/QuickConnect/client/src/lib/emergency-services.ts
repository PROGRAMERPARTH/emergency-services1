export interface EmergencyService {
  id: string;
  name: string;
  number: string;
  description: string;
  category: 'medical' | 'police' | 'fire' | 'support' | 'utility';
}

export const EMERGENCY_SERVICES: EmergencyService[] = [
  // Medical Services
  {
    id: 'ambulance',
    name: 'Ambulance',
    number: '108',
    description: 'Emergency medical transport',
    category: 'medical'
  },
  {
    id: 'medical-advice',
    name: 'Medical Advice (Maharashtra)',
    number: '104',
    description: 'Medical consultation helpline',
    category: 'medical'
  },
  {
    id: 'aids-helpline',
    name: 'AIDS Helpline (NACO)',
    number: '1097',
    description: 'AIDS related assistance',
    category: 'medical'
  },

  // Law Enforcement
  {
    id: 'police',
    name: 'Police Emergency',
    number: '100',
    description: 'General police assistance',
    category: 'police'
  },
  {
    id: 'universal-emergency',
    name: 'Unified Emergency Service',
    number: '112',
    description: 'Universal emergency number',
    category: 'police'
  },
  {
    id: 'women-crisis',
    name: 'Women Crisis Response',
    number: '1091',
    description: 'Women safety helpline',
    category: 'police'
  },
  {
    id: 'cyber-crime',
    name: 'Cyber Crime',
    number: '1930',
    description: 'Online fraud and cyber crime',
    category: 'police'
  },

  // Fire & Utility
  {
    id: 'fire-service',
    name: 'Fire Service',
    number: '101',
    description: 'Fire emergency response',
    category: 'fire'
  },
  {
    id: 'lpg-leakage',
    name: 'LPG Leakage Emergency',
    number: '1906',
    description: 'Gas leak emergency',
    category: 'utility'
  },
  {
    id: 'railway-accident',
    name: 'Railway Accident',
    number: '1072',
    description: 'Railway accident emergency',
    category: 'utility'
  },
  {
    id: 'railway-enquiry',
    name: 'Railway Enquiry',
    number: '139',
    description: 'Railway information',
    category: 'utility'
  },
  {
    id: 'road-accident',
    name: 'Road Accident Emergency',
    number: '1073',
    description: 'Road accident assistance',
    category: 'utility'
  },

  // Support Services
  {
    id: 'child-helpline',
    name: 'Child Helpline',
    number: '1098',
    description: 'Child protection and assistance',
    category: 'support'
  },
  {
    id: 'senior-citizen',
    name: 'Senior Citizen Helpline',
    number: '14567',
    description: 'Elderly care and support',
    category: 'support'
  },
  {
    id: 'consumer-helpline',
    name: 'National Consumer Helpline',
    number: '1800114000',
    description: 'Consumer complaints and protection',
    category: 'support'
  },
  {
    id: 'disaster-management',
    name: 'Emergency and Disaster Management',
    number: '1077',
    description: 'Disaster response and management',
    category: 'support'
  },
  {
    id: 'voter-helpline',
    name: 'Voter Helpline',
    number: '1950',
    description: 'Electoral assistance',
    category: 'support'
  },
  {
    id: 'kisan-call',
    name: 'Kisan Call Centre',
    number: '1551',
    description: 'Agricultural assistance',
    category: 'support'
  },
  {
    id: 'forest-department',
    name: 'Forest Department',
    number: '1926',
    description: 'Forest and wildlife emergencies',
    category: 'utility'
  },
  {
    id: 'tourist-helpline',
    name: 'Tourist Helpline',
    number: '1363',
    description: 'Tourist assistance',
    category: 'support'
  },
  {
    id: 'aadhaar-status',
    name: 'Aadhaar Card Status',
    number: '1947',
    description: 'Aadhaar related queries',
    category: 'support'
  },
  {
    id: 'anti-corruption',
    name: 'Anti Corruption',
    number: '1031',
    description: 'Report corruption',
    category: 'support'
  }
];

export const getServicesByCategory = (category: string) => {
  return EMERGENCY_SERVICES.filter(service => service.category === category);
};

export const searchServices = (query: string) => {
  if (!query.trim()) return EMERGENCY_SERVICES;
  
  const lowercaseQuery = query.toLowerCase();
  return EMERGENCY_SERVICES.filter(
    service => 
      service.name.toLowerCase().includes(lowercaseQuery) ||
      service.description.toLowerCase().includes(lowercaseQuery) ||
      service.number.includes(query)
  );
};
