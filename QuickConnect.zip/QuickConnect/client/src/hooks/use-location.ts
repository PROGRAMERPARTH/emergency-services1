import { useState, useCallback } from "react";

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}

export function useLocation() {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by this browser");
      return Promise.reject(new Error("Geolocation not supported"));
    }

    setIsLoading(true);
    setError(null);

    return new Promise<LocationData>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const locationData: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp,
          };
          setLocation(locationData);
          setIsLoading(false);
          resolve(locationData);
        },
        (error) => {
          let errorMessage = "Failed to get location";
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = "Location access denied by user";
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = "Location information unavailable";
              break;
            case error.TIMEOUT:
              errorMessage = "Location request timed out";
              break;
          }
          setError(errorMessage);
          setIsLoading(false);
          reject(new Error(errorMessage));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000,
        }
      );
    });
  }, []);

  const shareLocation = useCallback(async () => {
    try {
      const locationData = await getCurrentLocation();
      const locationUrl = `https://maps.google.com/maps?q=${locationData.latitude},${locationData.longitude}`;
      
      if (navigator.share) {
        await navigator.share({
          title: "My Emergency Location",
          text: `I need help! My location: ${locationUrl}`,
          url: locationUrl,
        });
      } else {
        // Fallback to copying to clipboard
        await navigator.clipboard.writeText(
          `Emergency Location: ${locationUrl}`
        );
        alert("Location copied to clipboard!");
      }
    } catch (error) {
      console.error("Failed to share location:", error);
      throw error;
    }
  }, [getCurrentLocation]);

  return {
    location,
    getCurrentLocation,
    shareLocation,
    isLoading,
    error,
  };
}
