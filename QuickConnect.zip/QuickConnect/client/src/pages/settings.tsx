import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { LogOut, User, Bell, Shield, Info } from "lucide-react";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);
  const [emergencyAlerts, setEmergencyAlerts] = useState(true);
  const { user, logout } = useAuth();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to logout. Please try again.",
        variant: "destructive",
      });
    }
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        toast({
          title: "Notifications Enabled",
          description: "You will now receive emergency notifications.",
        });
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-md mx-auto px-4 py-6 pb-20">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Settings</h1>

        {/* Profile Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Profile</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-sm font-medium">Name</Label>
              <p className="text-gray-600">{user?.fullName}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Username</Label>
              <p className="text-gray-600">@{user?.username}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Email</Label>
              <p className="text-gray-600">{user?.email}</p>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span>Emergency Settings</span>
            </CardTitle>
            <CardDescription>
              Configure your emergency preferences
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications">Emergency Notifications</Label>
                <p className="text-sm text-gray-500">
                  Receive alerts for emergency situations
                </p>
              </div>
              <Switch
                id="notifications"
                checked={notifications}
                onCheckedChange={(checked) => {
                  setNotifications(checked);
                  if (checked) {
                    requestNotificationPermission();
                  }
                }}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="location">Location Sharing</Label>
                <p className="text-sm text-gray-500">
                  Allow sharing location in emergencies
                </p>
              </div>
              <Switch
                id="location"
                checked={locationSharing}
                onCheckedChange={setLocationSharing}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="alerts">Emergency Alerts</Label>
                <p className="text-sm text-gray-500">
                  Send automatic alerts to emergency contacts
                </p>
              </div>
              <Switch
                id="alerts"
                checked={emergencyAlerts}
                onCheckedChange={setEmergencyAlerts}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={requestNotificationPermission}
              variant="outline" 
              className="w-full"
            >
              Enable Browser Notifications
            </Button>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Info className="w-5 h-5" />
              <span>About</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-gray-600">
              Emergency Services India - Version 1.0.0
            </p>
            <p className="text-sm text-gray-600">
              Quick access to Indian emergency services and personal emergency management.
            </p>
          </CardContent>
        </Card>

        {/* Logout */}
        <Card>
          <CardContent className="pt-6">
            <Button
              onClick={handleLogout}
              variant="destructive"
              className="w-full flex items-center space-x-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </Button>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
