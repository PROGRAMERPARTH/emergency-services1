import { useState } from "react";
import { User, AlertTriangle, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import QuickAccessPanel from "@/components/emergency/quick-access-panel";
import EmergencyCategories from "@/components/emergency/emergency-categories";
import SearchBar from "@/components/emergency/search-bar";
import { EMERGENCY_SERVICES, searchServices } from "@/lib/emergency-services";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();

  const filteredServices = searchServices(searchQuery);

  const [sosActive, setSosActive] = useState(false);
  
  const handleSOS = async () => {
    setSosActive(true);
    
    // Try to get location first
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error('Geolocation not supported'));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        });
      });

      const { latitude, longitude } = position.coords;
      const locationUrl = `https://maps.google.com/maps?q=${latitude},${longitude}`;
      
      // Show SOS options with location
      const action = confirm(
        `🚨 EMERGENCY SOS ACTIVATED 🚨\n\n` +
        `Location: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}\n\n` +
        `Choose action:\n` +
        `• OK - Call Emergency Services (112)\n` +
        `• Cancel - Share Location Only`
      );
      
      if (action) {
        // Call emergency services
        window.location.href = 'tel:112';
      } else {
        // Share location
        if (navigator.share) {
          await navigator.share({
            title: '🚨 EMERGENCY LOCATION',
            text: `Emergency assistance needed at this location:`,
            url: locationUrl
          });
        } else {
          // Fallback: copy to clipboard
          await navigator.clipboard.writeText(
            `🚨 EMERGENCY LOCATION: ${locationUrl}\nEmergency assistance needed at this location.`
          );
          alert('Location copied to clipboard! Share this with emergency contacts.');
        }
      }
    } catch (error) {
      console.error('Failed to get location:', error);
      
      // Fallback without location
      const action = confirm(
        `🚨 EMERGENCY SOS ACTIVATED 🚨\n\n` +
        `Unable to get location.\n\n` +
        `Choose action:\n` +
        `• OK - Call Emergency Services (112)\n` +
        `• Cancel - Continue`
      );
      
      if (action) {
        window.location.href = 'tel:112';
      }
    }
    
    setSosActive(false);
  };

  const showMyInfo = () => {
    alert(`Emergency Contact: ${user?.fullName || 'Unknown'}\nPhone: Call 112 for universal emergency`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <QuickAccessPanel />
      
      <SearchBar 
        value={searchQuery}
        onChange={setSearchQuery}
      />
      
      <EmergencyCategories services={filteredServices} />

      {/* SOS Emergency Button */}
      <div className="fixed bottom-20 right-6">
        <Button
          onClick={handleSOS}
          disabled={sosActive}
          className={`w-16 h-16 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-red-300 flex flex-col items-center justify-center ${
            sosActive 
              ? 'bg-red-800 animate-pulse' 
              : 'bg-red-600 hover:bg-red-700'
          } text-white`}
        >
          <AlertTriangle className="w-6 h-6 mb-1" />
          <span className="text-xs font-bold">SOS</span>
        </Button>
      </div>

      {/* User Info Button - smaller, positioned above SOS */}
      <div className="fixed bottom-40 right-6">
        <Button
          onClick={showMyInfo}
          className="w-12 h-12 bg-gray-600 hover:bg-gray-700 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-gray-300 flex items-center justify-center"
        >
          <User className="w-5 h-5" />
        </Button>
      </div>

      <BottomNav />
    </div>
  );
}
