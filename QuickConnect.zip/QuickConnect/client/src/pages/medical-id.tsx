import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { Plus, X, Heart } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { insertMedicalInfoSchema, type MedicalInfo } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

export default function MedicalId() {
  const { isAuthenticated } = useAuth();
  const [newAllergy, setNewAllergy] = useState("");
  const [newMedication, setNewMedication] = useState("");
  const [newCondition, setNewCondition] = useState("");
  const { toast } = useToast();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white rounded-lg shadow-md p-6">
            <Heart className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Login Required</h2>
            <p className="text-gray-600 mb-6">
              Please log in to manage your medical information and emergency health details.
            </p>
            <Link href="/auth">
              <Button className="w-full bg-red-600 hover:bg-red-700">
                Login to Continue
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const { data: medicalInfo, isLoading } = useQuery<MedicalInfo | null>({
    queryKey: ["/api/medical-info"],
  });

  const form = useForm({
    resolver: zodResolver(insertMedicalInfoSchema),
    defaultValues: {
      bloodType: medicalInfo?.bloodType || "",
      allergies: medicalInfo?.allergies || [],
      medications: medicalInfo?.medications || [],
      medicalConditions: medicalInfo?.medicalConditions || [],
      emergencyNotes: medicalInfo?.emergencyNotes || "",
      doctorName: medicalInfo?.doctorName || "",
      doctorPhone: medicalInfo?.doctorPhone || "",
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/medical-info", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medical-info"] });
      toast({
        title: "Medical Info Saved",
        description: "Your medical information has been saved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save medical information",
        variant: "destructive",
      });
    },
  });

  const currentAllergies = form.watch("allergies") || [];
  const currentMedications = form.watch("medications") || [];
  const currentConditions = form.watch("medicalConditions") || [];

  const addAllergy = () => {
    if (newAllergy.trim()) {
      form.setValue("allergies", [...currentAllergies, newAllergy.trim()]);
      setNewAllergy("");
    }
  };

  const removeAllergy = (index: number) => {
    form.setValue("allergies", currentAllergies.filter((_, i) => i !== index));
  };

  const addMedication = () => {
    if (newMedication.trim()) {
      form.setValue("medications", [...currentMedications, newMedication.trim()]);
      setNewMedication("");
    }
  };

  const removeMedication = (index: number) => {
    form.setValue("medications", currentMedications.filter((_, i) => i !== index));
  };

  const addCondition = () => {
    if (newCondition.trim()) {
      form.setValue("medicalConditions", [...currentConditions, newCondition.trim()]);
      setNewCondition("");
    }
  };

  const removeCondition = (index: number) => {
    form.setValue("medicalConditions", currentConditions.filter((_, i) => i !== index));
  };

  const onSubmit = (data: any) => {
    saveMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-md mx-auto px-4 py-6">
          <div className="text-center">Loading medical information...</div>
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-md mx-auto px-4 py-6 pb-20">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Medical ID</h1>

        <Card>
          <CardHeader>
            <CardTitle>Emergency Medical Information</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="bloodType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select blood type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="A+">A+</SelectItem>
                          <SelectItem value="A-">A-</SelectItem>
                          <SelectItem value="B+">B+</SelectItem>
                          <SelectItem value="B-">B-</SelectItem>
                          <SelectItem value="AB+">AB+</SelectItem>
                          <SelectItem value="AB-">AB-</SelectItem>
                          <SelectItem value="O+">O+</SelectItem>
                          <SelectItem value="O-">O-</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Allergies</FormLabel>
                  <div className="flex space-x-2 mt-2">
                    <Input
                      value={newAllergy}
                      onChange={(e) => setNewAllergy(e.target.value)}
                      placeholder="Add allergy"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addAllergy())}
                    />
                    <Button type="button" onClick={addAllergy} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {currentAllergies.map((allergy, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center space-x-1">
                        <span>{allergy}</span>
                        <Button
                          type="button"
                          onClick={() => removeAllergy(index)}
                          size="sm"
                          variant="ghost"
                          className="h-auto p-0 ml-1"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <FormLabel>Current Medications</FormLabel>
                  <div className="flex space-x-2 mt-2">
                    <Input
                      value={newMedication}
                      onChange={(e) => setNewMedication(e.target.value)}
                      placeholder="Add medication"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addMedication())}
                    />
                    <Button type="button" onClick={addMedication} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {currentMedications.map((medication, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center space-x-1">
                        <span>{medication}</span>
                        <Button
                          type="button"
                          onClick={() => removeMedication(index)}
                          size="sm"
                          variant="ghost"
                          className="h-auto p-0 ml-1"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <FormLabel>Medical Conditions</FormLabel>
                  <div className="flex space-x-2 mt-2">
                    <Input
                      value={newCondition}
                      onChange={(e) => setNewCondition(e.target.value)}
                      placeholder="Add condition"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCondition())}
                    />
                    <Button type="button" onClick={addCondition} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {currentConditions.map((condition, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center space-x-1">
                        <span>{condition}</span>
                        <Button
                          type="button"
                          onClick={() => removeCondition(index)}
                          size="sm"
                          variant="ghost"
                          className="h-auto p-0 ml-1"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="doctorName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Primary Doctor</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Dr. Name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="doctorPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Doctor's Phone</FormLabel>
                      <FormControl>
                        <Input type="tel" {...field} placeholder="+91 XXXXXXXXXX" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="emergencyNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Emergency Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          placeholder="Any additional information for emergency responders..."
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={saveMutation.isPending}>
                  {saveMutation.isPending ? "Saving..." : "Save Medical Information"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
