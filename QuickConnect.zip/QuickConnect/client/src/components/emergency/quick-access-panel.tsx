import { Shield, Heart, Flame, Phone, MapPin, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "@/hooks/use-location";
import { useToast } from "@/hooks/use-toast";

export default function QuickAccessPanel() {
  const { shareLocation } = useLocation();
  const { toast } = useToast();

  const dialEmergency = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  const handleShareLocation = async () => {
    try {
      await shareLocation();
      toast({
        title: "Location Shared",
        description: "Your location has been shared successfully.",
      });
    } catch (error) {
      toast({
        title: "Location Error",
        description: "Failed to share location. Please try again.",
        variant: "destructive",
      });
    }
  };

  const sendAlert = () => {
    const message = "EMERGENCY: I need immediate assistance. Please help!";
    if (navigator.share) {
      navigator.share({
        title: "Emergency Alert",
        text: message,
      }).catch(() => {
        // Fallback to SMS
        window.location.href = `sms:?body=${encodeURIComponent(message)}`;
      });
    } else {
      window.location.href = `sms:?body=${encodeURIComponent(message)}`;
    }
  };

  return (
    <section className="max-w-md mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Emergency Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          {/* Police Emergency Button */}
          <Button
            onClick={() => dialEmergency("100")}
            className="police-blue text-white p-6 h-auto rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-blue-300"
          >
            <div className="text-center">
              <Shield className="w-8 h-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">100</div>
              <div className="text-sm font-medium">Police</div>
            </div>
          </Button>

          {/* Medical Emergency Button */}
          <Button
            onClick={() => dialEmergency("108")}
            className="medical-green text-white p-6 h-auto rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-green-300"
          >
            <div className="text-center">
              <Heart className="w-8 h-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">108</div>
              <div className="text-sm font-medium">Ambulance</div>
            </div>
          </Button>

          {/* Fire Emergency Button */}
          <Button
            onClick={() => dialEmergency("101")}
            className="fire-orange text-white p-6 h-auto rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-orange-300"
          >
            <div className="text-center">
              <Flame className="w-8 h-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">101</div>
              <div className="text-sm font-medium">Fire Service</div>
            </div>
          </Button>

          {/* Universal Emergency Button */}
          <Button
            onClick={() => dialEmergency("112")}
            className="emergency-red text-white p-6 h-auto rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-red-300"
          >
            <div className="text-center">
              <Phone className="w-8 h-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">112</div>
              <div className="text-sm font-medium">Universal</div>
            </div>
          </Button>
        </div>
      </div>

      {/* Location & Alert Actions */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <Button
          onClick={handleShareLocation}
          variant="outline"
          className="text-gray-700 p-4 h-auto rounded-xl border-2 border-gray-300 hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-blue-300"
        >
          <div className="text-center">
            <MapPin className="w-6 h-6 mx-auto mb-2 text-blue-600" />
            <div className="text-sm font-medium">Share Location</div>
          </div>
        </Button>

        <Button
          onClick={sendAlert}
          variant="outline"
          className="text-gray-700 p-4 h-auto rounded-xl border-2 border-gray-300 hover:border-orange-400 hover:bg-orange-50 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-orange-300"
        >
          <div className="text-center">
            <Volume2 className="w-6 h-6 mx-auto mb-2 text-orange-600" />
            <div className="text-sm font-medium">Send Alert</div>
          </div>
        </Button>
      </div>
    </section>
  );
}
