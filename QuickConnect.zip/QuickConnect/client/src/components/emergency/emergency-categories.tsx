import { useState } from "react";
import { Heart, Shield, Users, Wrench, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmergencyService } from "@/lib/emergency-services";

interface EmergencyCategoriesProps {
  services: EmergencyService[];
}

const categoryConfig = {
  medical: {
    name: "Medical Services",
    description: "Emergency medical assistance",
    icon: Heart,
    bgColor: "bg-green-50 hover:bg-green-100",
    iconBg: "medical-green",
    buttonColor: "medical-green hover:bg-green-700",
  },
  police: {
    name: "Law Enforcement",
    description: "Police and security services",
    icon: Shield,
    bgColor: "bg-blue-50 hover:bg-blue-100",
    iconBg: "police-blue",
    buttonColor: "police-blue hover:bg-blue-700",
  },
  support: {
    name: "Support Services",
    description: "Helplines and assistance",
    icon: Users,
    bgColor: "bg-purple-50 hover:bg-purple-100",
    iconBg: "support-purple",
    buttonColor: "support-purple hover:bg-purple-700",
  },
  utility: {
    name: "Utility Services",
    description: "Fire, gas, and public services",
    icon: Wrench,
    bgColor: "bg-orange-50 hover:bg-orange-100",
    iconBg: "fire-orange",
    buttonColor: "fire-orange hover:bg-orange-700",
  },
  fire: {
    name: "Fire Services",
    description: "Fire emergency response",
    icon: Wrench,
    bgColor: "bg-orange-50 hover:bg-orange-100",
    iconBg: "fire-orange",
    buttonColor: "fire-orange hover:bg-orange-700",
  },
};

export default function EmergencyCategories({ services }: EmergencyCategoriesProps) {
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  const dialNumber = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(category)) {
        newSet.delete(category);
      } else {
        newSet.add(category);
      }
      return newSet;
    });
  };

  // Group services by category
  const servicesByCategory = services.reduce((acc, service) => {
    if (!acc[service.category]) {
      acc[service.category] = [];
    }
    acc[service.category].push(service);
    return acc;
  }, {} as Record<string, EmergencyService[]>);

  return (
    <section className="max-w-md mx-auto px-4 pb-20">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Emergency Services Directory</h2>
      
      {Object.entries(servicesByCategory).map(([category, categoryServices]) => {
        const config = categoryConfig[category as keyof typeof categoryConfig];
        if (!config) return null;

        const isExpanded = expandedCategories.has(category);
        const Icon = config.icon;

        return (
          <Card key={category} className="mb-4 overflow-hidden">
            <Button
              onClick={() => toggleCategory(category)}
              variant="ghost"
              className={`w-full px-6 py-4 text-left ${config.bgColor} transition-colors flex items-center justify-between`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${config.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{config.name}</h3>
                  <p className="text-sm text-gray-600">{config.description}</p>
                </div>
              </div>
              <ChevronRight 
                className={`w-5 h-5 text-gray-400 transition-transform ${
                  isExpanded ? 'rotate-90' : ''
                }`} 
              />
            </Button>
            
            {isExpanded && categoryServices.map((service) => (
              <div key={service.id} className="px-6 py-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-gray-900">{service.name}</h4>
                    <p className="text-sm text-gray-600">{service.description}</p>
                  </div>
                  <Button
                    onClick={() => dialNumber(service.number)}
                    className={`px-4 py-2 ${config.buttonColor} text-white rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2`}
                  >
                    Call {service.number}
                  </Button>
                </div>
              </div>
            ))}
          </Card>
        );
      })}
    </section>
  );
}
