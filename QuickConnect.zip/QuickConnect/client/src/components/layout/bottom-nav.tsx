import { Home, Phone, FileText, Settings } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/contacts", icon: Phone, label: "Contacts" },
    { path: "/medical-id", icon: FileText, label: "Medical ID" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 max-w-md mx-auto">
      <div className="grid grid-cols-4">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location === path;
          return (
            <Link key={path} href={path} className="p-4 text-center hover:bg-gray-50 transition-colors">
              <Icon
                className={`w-6 h-6 mx-auto mb-1 ${
                  isActive ? "text-red-600" : "text-gray-500"
                }`}
              />
              <span
                className={`text-xs font-medium ${
                  isActive ? "text-red-600" : "text-gray-500"
                }`}
              >
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
