import { Menu, AlertTriangle, User, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

interface HeaderProps {
  onMenuClick?: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const { isAuthenticated, user } = useAuth();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-md mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 emergency-red rounded-full flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">Emergency Services</h1>
              <p className="text-xs text-gray-500">India Emergency Contacts</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isAuthenticated ? (
              <Link href="/settings">
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors flex items-center space-x-1"
                >
                  <User className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-600">{user?.fullName}</span>
                </Button>
              </Link>
            ) : (
              <Link href="/auth">
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors flex items-center space-x-1"
                >
                  <LogIn className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-600">Login</span>
                </Button>
              </Link>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={onMenuClick}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <Menu className="w-6 h-6 text-gray-600" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
