# Emergency Services Application

## Overview

This is a React-based emergency services application built with Express.js backend that provides users with quick access to emergency contacts, medical information management, and various emergency services in India. The application features a mobile-first design and includes authentication, emergency contact management, medical ID storage, and quick access to emergency services.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture with clear separation between client and server components:

- **Frontend**: React + TypeScript with Vite for development and building
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for data persistence
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Authentication**: Session-based authentication with bcrypt password hashing

## Key Components

### Frontend Architecture

1. **Component Structure**:
   - Pages: `home`, `contacts`, `medical-id`, `settings`, `auth`
   - Layout components: `header`, `bottom-nav`
   - Emergency-specific components: `quick-access-panel`, `emergency-categories`, `search-bar`
   - UI components from shadcn/ui library

2. **State Management**:
   - TanStack Query for API calls and caching
   - Custom hooks for authentication (`use-auth`), location services (`use-location`), and mobile detection (`use-mobile`)
   - React Hook Form for form validation with Zod schemas

3. **Styling**:
   - Tailwind CSS with custom emergency service color variables
   - Responsive design optimized for mobile devices
   - Dark/light theme support

### Backend Architecture

1. **Server Structure**:
   - Express.js application with middleware for logging and error handling
   - Route handlers for authentication and data management
   - In-memory storage implementation with interface for future database integration

2. **Authentication**:
   - Session-based authentication using express-session
   - Password hashing with bcrypt
   - Protected routes with authentication middleware

3. **Data Models**:
   - Users: Basic user information and authentication
   - Emergency Contacts: Personal emergency contact management
   - Medical Information: Health data including blood type, allergies, medications

### Database Schema

The application uses Drizzle ORM with PostgreSQL and includes three main tables:

1. **users**: User authentication and profile information
2. **emergency_contacts**: Personal emergency contacts with relationship details
3. **medical_info**: Medical information including allergies, medications, and emergency notes

### External Dependencies

1. **UI Framework**: 
   - Radix UI primitives for accessible components
   - Lucide React for icons
   - shadcn/ui component library

2. **Backend Services**:
   - Neon Database serverless for PostgreSQL hosting
   - Express session management
   - bcrypt for password security

3. **Development Tools**:
   - Vite for development server and building
   - TypeScript for type safety
   - ESBuild for server bundling

## Data Flow

1. **Authentication Flow**:
   - User registration/login through form validation
   - Session creation and management
   - Protected route access control

2. **Emergency Services**:
   - Static emergency service data with search functionality
   - Quick access buttons for immediate emergency calls
   - Location sharing capabilities

3. **Data Management**:
   - CRUD operations for emergency contacts
   - Medical information storage and updates
   - Real-time form validation and error handling

## External Integrations

1. **Geolocation API**: For location sharing during emergencies
2. **Phone Dialing**: Direct phone call initiation for emergency services
3. **SMS/Share API**: For emergency alert messaging
4. **Notification API**: For emergency notifications (when permissions granted)

## Deployment Strategy

The application is configured for deployment with:

1. **Build Process**:
   - Vite builds the React frontend to `dist/public`
   - ESBuild bundles the Express server to `dist/index.js`
   - Static file serving in production

2. **Environment Configuration**:
   - Database URL configuration for Drizzle ORM
   - Session management setup
   - Development vs production environment handling

3. **Database Management**:
   - Drizzle migrations in `./migrations` directory
   - Push-based schema updates for development
   - PostgreSQL dialect configuration

The architecture prioritizes rapid development, type safety, and mobile user experience while maintaining a clear separation of concerns between frontend and backend components.